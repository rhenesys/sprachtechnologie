package start;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ConnectionDB {
	
	 	private Connection connection;
	    private String host, database, username, password;
	    private int port;
	   
	    
	    public void onEnable() {  
	        host = "localhost";
	        port = 3306;
	        database = "sozialraum_db";
	        username = "root";
	        password = "root"; 
	    }
	  
	    public void onDisable() {
	    	
	    }
	    
	    public byte[] picturesHolen(int index,String kategorie) throws SQLException
	    {
	    		
	    	onEnable();
	    	Blob imageBlob = null;
	    	try{
	    		openConnection();
	    		String query = "SELECT bild FROM sozialraum_db.kategorie WHERE name = 'Sozialraum';";
	    		Statement statement = connection.createStatement();
		    	ResultSet result = statement.executeQuery(query);
		    	imageBlob = result.getBlob("bild");
		    			    	
	    	}
	    	catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
			return imageBlob.getBytes(1, (int)imageBlob.length());
			
	    }
	    
	    /*
	     * 
	     */
	    public void oberkategorie_data_hinzufuegen(String data)
	    {
	    	onEnable();
	    	try{
	    		openConnection();
	    		PreparedStatement preparedStmt = connection.prepareStatement("INSERT INTO sozialraum_db.oberkategorien(oberkategorie)VALUES(?)");
	    		preparedStmt.setString(1, data);
	    		preparedStmt.execute();
	    		
	    	}
	    	catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    }
	    
	    public void feedback_hinzufuegen(String datum, String betreff, String mail, String text)
	    {
	    	onEnable();
	    	try{
	    		openConnection();
	    		PreparedStatement preparedStmt = connection.prepareStatement("INSERT INTO sozialraum_db.feedback(datum,betreff,mail,text)VALUES(?,?,?,?)");
	    		preparedStmt.setString(1, datum);
	    		preparedStmt.setString(2, betreff);
	    		preparedStmt.setString(3, mail);
	    		preparedStmt.setString(4, text);
	    		preparedStmt.execute();
	    		
	    	}
	    	catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    }
	    
	    public void unterkategorie_data_hinzufuegen(String data)
	    {
	    	onEnable();
	    	try{
	    		openConnection();
	    		PreparedStatement preparedStmt = connection.prepareStatement("INSERT INTO sozialraum_db.unterkategorien(unterkategorie)VALUES(?)");
	    		preparedStmt.setString(1, data);
	    		preparedStmt.execute();
	    		
	    	}
	    	catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    }
	    
	    public void deleteTraeger(List<String> zuDeletenTraeger)
	    {
	    	onEnable();
	    	try{
	    		openConnection();
	    		for(int index = 0; index < zuDeletenTraeger.size(); ++index)
	    		{
	    			String id = "";
	    			Statement idHolen = connection.createStatement();
	    			ResultSet rs = idHolen.executeQuery("SELECT id FROM sozialraum_db.traeger WHERE name = '"+zuDeletenTraeger.get(index)+"'");
	    			
	    			if(rs.next())
	    			{
	    				id = rs.getString(1);
	    			}
	    			
	    			//System.out.println("DELETE FROM sozialraum_db.traeger WHERE id = "+Integer.parseInt(id)+";");
		    		PreparedStatement pstmt_update_traeger = connection.prepareStatement("DELETE FROM sozialraum_db.traeger WHERE id = "+Integer.parseInt(id)+";");
		    		PreparedStatement pstmt_update_traeger_kat_mapping = connection.prepareStatement("DELETE FROM sozialraum_db.traeger_kat_mapping WHERE traeger_id = "+Integer.parseInt(id)+";");
		    		pstmt_update_traeger.executeUpdate();
		    		pstmt_update_traeger_kat_mapping.executeUpdate();
	    		}
	    		
	    	}catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    }
	    
	    
	    public List<String> getTraegerData(String query) throws SQLException
	    {
	    	LinkedList<String> erg = new LinkedList<String>();
	    	onEnable();
	    	try{
	    		openConnection();
	    		Statement statement = connection.createStatement();
	    		ResultSet result = statement.executeQuery(query);
	    		while(result.next())
	    		{
	    			ResultSetMetaData rsmd = result.getMetaData();
	    			//System.out.println(rsmd);
	    			for(int i = 1; i <= rsmd.getColumnCount(); i++)
	    			{
	    				int type = rsmd.getColumnType(i);
	    				if(type == Types.VARCHAR)
	    				{
	    					erg.add(result.getString(i));
	    					System.out.println(result.getString(i));
	    				}
	    			}
	    		}
	    	}catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
			return erg;
	    }
	    
	    public List<String> data(String query, String gesuchteSpalte) throws SQLException
	    {
	    	onEnable();
	    	List<String> ergebnisAbfrage = null;
	    	try{
	    		openConnection();
		    	Statement statement = connection.createStatement();
		    	ResultSet result = statement.executeQuery(query);
		    	ergebnisAbfrage = new ArrayList<String>();
	    	while (result.next()) {
	    	    String name = result.getString(gesuchteSpalte);
	    	    ergebnisAbfrage.add(name);
	    	}
	    	}catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    	
				
			closeConnection();
			
	    	return ergebnisAbfrage;
	    }
	    
	    public void printErg(List<String> eingabe)
	    {
	    	for(String s: eingabe)
	    	{
	    		System.out.println(s);
	    	}
	    }
	    
	    public  void closeConnection() throws SQLException
	    {
	    	connection.close();
	    }
	    
	    public void openConnection() throws SQLException, ClassNotFoundException {
	        if (connection != null && !connection.isClosed()) {
	            return;
	        }

	        synchronized (this) {
	            if (connection != null && !connection.isClosed()) {
	                return;
	            }
	            Class.forName("com.mysql.jdbc.Driver");
	            connection = DriverManager.getConnection("jdbc:mysql://" + this.host + ":" + this.port + "/" + this.database+"?autoReconnect=true&useSSL=False", this.username, this.password);
	        }
	    }
	}

