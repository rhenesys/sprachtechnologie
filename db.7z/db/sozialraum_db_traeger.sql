-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: sozialraum_db
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `traeger`
--

DROP TABLE IF EXISTS `traeger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `traeger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `plz` varchar(10) DEFAULT NULL,
  `strasse` varchar(150) DEFAULT NULL,
  `hausnummer` varchar(10) DEFAULT NULL,
  `telefon` varchar(45) DEFAULT NULL,
  `fax` varchar(45) DEFAULT NULL,
  `ansprechpartner` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `website` varchar(200) DEFAULT NULL,
  `angebot` varchar(700) DEFAULT NULL,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `text` (`angebot`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `traeger`
--

LOCK TABLES `traeger` WRITE;
/*!40000 ALTER TABLE `traeger` DISABLE KEYS */;
INSERT INTO `traeger` VALUES (1,'Beratungszentrum Roma und Cinti Union e.V.','22041','Am Neumarkt','38','040/ 31 05 21','040/ 31 04 75','Frau Mueller','rcu.ev@web.de','https://www.rcu-info.de/beratungszentrum.html','Roma, Sinti und Bürger, \"Begegnungsstelle, Vermittlung ins Hilfesystem, Unterstützung bei \nexistentieller Sicherung und Wohnungs-und Arbeitssuche, \nInformationen zu Behörden, Mediation, Unterstützung bei \nKinder-und Altenbetreuung, Übersetzungsdienste, Jugendarbeit, Öffentlichkeitsarbeit... \"'),(2,'Johann-Daniel-Lawaetz-Stiftung, Jugend Aktiv Plus','23432','Lutterothstr','12','123134234','234234234','Sieglinde Ritz und Runhild Mehrkens','ritz@lawaetz.de; mehrkens@lawaetz.de','http://jugendaktivplus-hamburg.de/home.html','\"arbeitslose Jugendliche und junge Erwachsene, junge Eltern \nbis 27 mit Vermittlungshemmnissen\"'),(18,'Hagenbecksschule','12332','hagenbeckstr','99','0900090900','098098889','Herr Schulz','schulz@hotmail.com','','Als Zufallstext wird speziell in der Kryptologie ein Text bezeichnet, in dem alle Zeichen (zumeist nur Buchstaben, gelegentlich auch Zahlen) „möglichst zufällig“, also unabhängig voneinander und mit gleicher Wahrscheinlichkeit auftreten. Idealerweise sollten stark verschlüsselte Texte, also „gute“ Geheimtexte, von Zufallstexten nicht zu unterscheiden sein, um die Kryptanalyse und den Bruch (Entzifferung) zu erschweren.'),(21,'Fit for Future','22143','Großlohering','49','9823704298374','02893704289',NULL,'mail@hotmail.com','www.fitforfuture.de','wir machen dinge'),(27,'eiff','20537','eiff','345A','34343434','34343434',NULL,'asf@hotmail.com','asdf.com','asdöuifahpwieufhäq2f'),(28,'Wichern Schule','12445','Horner weg','1','0400009999','040009809808',NULL,'wichern@schule.com','wichernschule.com','Sprachangebote, Informatik, Sport usw.'),(29,'a','12312','b','c','a','a',NULL,'a','a','a');
/*!40000 ALTER TABLE `traeger` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-01 15:21:01
