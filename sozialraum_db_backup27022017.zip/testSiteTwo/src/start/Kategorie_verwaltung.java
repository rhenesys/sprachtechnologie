package start;

import java.util.LinkedList;
import java.util.List;

public class Kategorie_verwaltung {
	
	//m�sste dynamisch aus der DB gelesen werden
	private static List<String> total_ober_kategorien = new LinkedList<String>();
	
	public Kategorie_verwaltung()
	{
		
	}
	
	public void kategorien_holen()
	{
		ConnectionDB con = new ConnectionDB();
		//con.data("INSERT INTO sozialraum_db.oberkategorien(oberkategorie)VALUES(?)", gesuchteSpalte);
	}
	
	public void kategorie_hinzufuegen(String name)
	{
		total_ober_kategorien.add(name);
	}
	
	
}
