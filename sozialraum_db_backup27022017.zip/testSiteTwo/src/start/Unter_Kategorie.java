package start;

public class Unter_Kategorie {
	private String name;
	public Unter_Kategorie(String name)
	{
		this.name = name;
	}
	
	public String getName()
	{
		return name;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
}
