package start;

import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

public class ConnectionDB {
	
	 	private Connection connection;
	    private String host, database, username, password;
	    private int port;
	   
	    
	    public void onEnable() {  
	        host = "localhost";
	        port = 3306;
	        database = "sozialraum_db";
	        username = "root";
	        password = "root"; 
	    }
	  
	    public void onDisable() {
	    	
	    }
	    
	    public byte[] picturesHolen(int index,String kategorie) throws SQLException
	    {
	    		
	    	onEnable();
	    	Blob imageBlob = null;
	    	try{
	    		openConnection();
	    		String query = "SELECT bild FROM sozialraum_db.kategorie WHERE name = 'Sozialraum';";
	    		Statement statement = connection.createStatement();
		    	ResultSet result = statement.executeQuery(query);
		    	imageBlob = result.getBlob("bild");
		    			    	
	    	}
	    	catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
			return imageBlob.getBytes(1, (int)imageBlob.length());
			
	    }
	    
	    /*
	     * 
	     */
	    public void oberkategorie_data_hinzufuegen(String data)
	    {
	    	onEnable();
	    	try{
	    		openConnection();
	    		PreparedStatement preparedStmt = connection.prepareStatement("INSERT INTO sozialraum_db.oberkategorien(oberkategorie)VALUES(?)");
	    		preparedStmt.setString(1, data);
	    		preparedStmt.execute();
	    		
	    	}
	    	catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    }
	    
	    public void unterkategorie_data_hinzufuegen(String data)
	    {
	    	onEnable();
	    	try{
	    		openConnection();
	    		PreparedStatement preparedStmt = connection.prepareStatement("INSERT INTO sozialraum_db.unterkategorien(unterkategorie)VALUES(?)");
	    		preparedStmt.setString(1, data);
	    		preparedStmt.execute();
	    		
	    	}
	    	catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    }
	    	       
	    public List<String> data(String query, String gesuchteSpalte) throws SQLException
	    {
	    	onEnable();
	    	List<String> ergebnisAbfrage = null;
	    	try{
	    		openConnection();
		    	Statement statement = connection.createStatement();
		    	ResultSet result = statement.executeQuery(query);
		    	ergebnisAbfrage = new ArrayList<String>();
	    	while (result.next()) {
	    	    String name = result.getString(gesuchteSpalte);
	    	    ergebnisAbfrage.add(name);
	    	}
	    	}catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    	
				
			closeConnection();
			
	    	return ergebnisAbfrage;
	    }
	    
	    public void printErg(List<String> eingabe)
	    {
	    	for(String s: eingabe)
	    	{
	    		System.out.println(s);
	    	}
	    }
	    
	    public  void closeConnection() throws SQLException
	    {
	    	connection.close();
	    }
	    
	    public void openConnection() throws SQLException, ClassNotFoundException {
	        if (connection != null && !connection.isClosed()) {
	            return;
	        }

	        synchronized (this) {
	            if (connection != null && !connection.isClosed()) {
	                return;
	            }
	            Class.forName("com.mysql.jdbc.Driver");
	            connection = DriverManager.getConnection("jdbc:mysql://" + this.host + ":" + this.port + "/" + this.database+"?autoReconnect=true&useSSL=False", this.username, this.password);
	        }
	    }
	}

