package start;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.sql.ResultSet;

public class ConnectionDB {
	
	 	private Connection connection;
	    private static final String host, database, username, password;
	    private static final int port;
	   
	    
	    static {  
	        host = "localhost";
	        port = 3306;
	        database = "sozialraum_db";
	        username = "root";
	        password = "root"; 
	    }
	  
	    public void onDisable()
	    {
	    	
	    }
	    
	    public void updateBild(String sql, byte[] bild) throws SQLException
	    {
	    	
	    	try{
	    		openConnection();
	    		PreparedStatement stmt = connection.prepareStatement(sql);
	    		stmt.setBytes(1, bild);
	    		stmt.executeUpdate();
	    	}catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    	
			closeConnection();
			
	    }
	    
	    public void deleteKategorie(String sql) throws SQLException
	    {
	    	
	    	try{
	    		openConnection();
	    		PreparedStatement stmt = connection.prepareStatement(sql);
	    		stmt.executeUpdate();
	    	}catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    	
			closeConnection();
			
	    }
	    
	    public byte[] picturesHolen(int index,String kategorie) throws SQLException
	    {
	    		
	    	
	    	Blob imageBlob = null;
	    	try{
	    		openConnection();
	    		String query = "SELECT bild FROM sozialraum_db.kategorie WHERE name = 'Sozialraum';";
	    		Statement statement = connection.createStatement();
		    	ResultSet result = statement.executeQuery(query);
		    	imageBlob = result.getBlob("bild");
		    			    	
	    	}
	    	catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    	
			closeConnection();
			
			return imageBlob.getBytes(1, (int)imageBlob.length());
			
	    }
	    
	    public ResultSet queryAusfuehren(String sql) throws SQLException
	    {
	    	
	    	ResultSet rs = null;
	    	try{
	    		openConnection();
	    		Statement prstmt = connection.createStatement();
		    	rs = prstmt.executeQuery(sql);
		    	
	    	}catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    	
			return rs;
	    	
	    }
	    
	    /*
	     * 
	     */
	    public void oberkategorie_data_hinzufuegen(String data) throws SQLException
	    {
	    	
	    	try{
	    		openConnection();
	    		PreparedStatement preparedStmt = connection.prepareStatement("INSERT INTO sozialraum_db.oberkategorien(oberkategorie)VALUES(?)");
	    		preparedStmt.setString(1, data);
	    		preparedStmt.execute();
	    		
	    	}
	    	catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    	
			closeConnection();
			
	    }
	    
	    public void bildKatHinzufuegen(InputStream input) throws IOException, SQLException
	    {
	    	
	    	System.out.println(input.read());
	    	try{
	    		openConnection();
	    		if(input != null)
	    		{
	    			String sql = "INSERT INTO sozialraum_db.kategorie (name,bild) VALUES (?,?)";
	    			PreparedStatement ps = connection.prepareStatement(sql);
	    			ps.setString(1, "TEST");
	    			ps.setBlob(2, input);
	    			ps.executeUpdate();
	    		}
	    	}catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    	
	    	
			closeConnection();
			
	    }
	    
	    public int stringMonatInIntMonat(String monat)
	    {
	    	int intMonat = 0;
	    	switch(monat)
	    	{
	    	case "Januar": intMonat = 1;
	    	break;
	    	case "Februar": intMonat = 2;
	    	break;
	    	case "M�rz": intMonat = 3;
	    	break;
	    	case "April": intMonat = 4;
	    	break;
	    	case "Mai": intMonat = 5;
	    	break;
	    	case "Juni": intMonat = 6;
	    	break;
	    	case "Juli": intMonat = 7;
	    	break;
	    	case "August": intMonat = 8;
	    	break;
	    	case "September": intMonat = 9;
	    	break;
	    	case "Oktober": intMonat = 10;
	    	break;
	    	case "November": intMonat = 11;
	    	break;
	    	case "Dezember": intMonat = 12;
	    	break;
	    	}
	    	return intMonat;
	    }
	    
	    public LinkedList<String> getFeedback(String monat, String jahr) throws SQLException
	    {
	    	LinkedList<String> ausgabe = new LinkedList<String>();
	    	
	    	try{
	    		openConnection();
	    		PreparedStatement preparedStmt = connection.prepareStatement("SELECT * FROM sozialraum_db.feedback WHERE MONTH(datum) = "+stringMonatInIntMonat(monat)+" AND YEAR(datum) = "+jahr+";");
	    		ResultSet rs = preparedStmt.executeQuery();
	    		while(rs.next())
	    		{
	    			ResultSetMetaData rsmd = rs.getMetaData();
	    			//System.out.println(rsmd);
	    			for(int i = 1; i <= rsmd.getColumnCount(); i++)
	    			{
	    				int type = rsmd.getColumnType(i);
	    				if(type == Types.VARCHAR)
	    				{
	    					ausgabe.add(rs.getString(i));
	    				}
	    			}
	    		}
	    	}catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    	
			closeConnection();
			
	    	return ausgabe;
	    }
	    
	    public void feedback_hinzufuegen(String datum, String betreff, String mail, String text) throws SQLException
	    {
	    	
	    	try{
	    		openConnection();
	    		PreparedStatement preparedStmt = connection.prepareStatement("INSERT INTO sozialraum_db.feedback(datum,betreff,mail,text)VALUES(?,?,?,?)");
	    		preparedStmt.setString(1, datum);
	    		preparedStmt.setString(2, betreff);
	    		preparedStmt.setString(3, mail);
	    		preparedStmt.setString(4, text);
	    		preparedStmt.execute();
	    		
	    	}
	    	catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    	
			closeConnection();
			
	    }
	    
	    public void unterkategorie_data_hinzufuegen(String data) throws SQLException
	    {
	    	
	    	try{
	    		openConnection();
	    		PreparedStatement preparedStmt = connection.prepareStatement("INSERT INTO sozialraum_db.unterkategorien(unterkategorie)VALUES(?)");
	    		preparedStmt.setString(1, data);
	    		preparedStmt.execute();
	    		
	    	}
	    	catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    	
			closeConnection();
			
	    }
	    
	    public void deleteTraeger(List<String> zuDeletenTraeger) throws SQLException
	    {
	    	
	    	try{
	    		openConnection();
	    		for(int index = 0; index < zuDeletenTraeger.size(); ++index)
	    		{
	    			String id = "";
	    			Statement idHolen = connection.createStatement();
	    			ResultSet rs = idHolen.executeQuery("SELECT id FROM sozialraum_db.traeger WHERE name = '"+zuDeletenTraeger.get(index)+"'");
	    			
	    			if(rs.next())
	    			{
	    				id = rs.getString(1);
	    			}
	    			
	    			//System.out.println("DELETE FROM sozialraum_db.traeger WHERE id = "+Integer.parseInt(id)+";");
		    		PreparedStatement pstmt_update_traeger = connection.prepareStatement("DELETE FROM sozialraum_db.traeger WHERE id = "+Integer.parseInt(id)+";");
		    		PreparedStatement pstmt_update_traeger_kat_mapping = connection.prepareStatement("DELETE FROM sozialraum_db.traeger_kat_mapping WHERE traeger_id = "+Integer.parseInt(id)+";");
		    		pstmt_update_traeger.executeUpdate();
		    		pstmt_update_traeger_kat_mapping.executeUpdate();
	    		}
	    		
	    	}catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    	
			closeConnection();
			
	    }
	    
	    
	    public List<String> getTraegerData(String query) throws SQLException
	    {
	    	LinkedList<String> erg = new LinkedList<String>();
	    	
	    	try{
	    		openConnection();
	    		Statement statement = connection.createStatement();
	    		ResultSet result = statement.executeQuery(query);
	    		while(result.next())
	    		{
	    			ResultSetMetaData rsmd = result.getMetaData();
	    			//System.out.println(rsmd);
	    			for(int i = 1; i <= rsmd.getColumnCount(); i++)
	    			{
	    				int type = rsmd.getColumnType(i);
	    				if(type == Types.VARCHAR)
	    				{
	    					erg.add(result.getString(i));
	    				}
	    			}
	    		}
	    	}catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    	
			closeConnection();
			
			return erg;
	    }
	    
	    public List<String> data(String query, String gesuchteSpalte) throws SQLException
	    {
	    	
	    	List<String> ergebnisAbfrage = null;
	    	try{
	    		openConnection();
		    	Statement statement = connection.createStatement();
		    	ResultSet result = statement.executeQuery(query);
		    	ergebnisAbfrage = new ArrayList<String>();
	    	while (result.next()) {
	    	    String name = result.getString(gesuchteSpalte);
	    	    ergebnisAbfrage.add(name);
	    	}
	    	}catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    	
				
			closeConnection();
			
	    	return ergebnisAbfrage;
	    }
	    
	    public void printErg(List<String> eingabe)
	    {
	    	for(String s: eingabe)
	    	{
	    		System.out.println(s);
	    	}
	    }
	    
	    public  void closeConnection() throws SQLException
	    {
	    	connection.close();
	    }
	    
	    public void openConnection() throws SQLException, ClassNotFoundException {
	        if (connection != null && !connection.isClosed()) {
	            return;
	        }

	        synchronized (this) {
	            if (connection != null && !connection.isClosed()) {
	                return;
	            }
	            connection = createConnection();
	        }
	    }
	    
	    
	    public static Connection createConnection() throws SQLException, ClassNotFoundException {
	        Class.forName("com.mysql.jdbc.Driver");
	        return DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + database+"?autoReconnect=true&useSSL=False", username, password);
	        
	    }
	}

