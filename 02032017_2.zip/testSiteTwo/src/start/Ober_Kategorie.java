package start;

import java.util.LinkedList;
import java.util.List;

public class Ober_Kategorie {
	
	protected List<Unter_Kategorie> list_Kategorien = new LinkedList<Unter_Kategorie>();
	private String name;
	
	public Ober_Kategorie(String name)
	{
		this.name = name;
	}
		
	public String get_Ober_Kategorie_Name()
	{
		return name;
	}
	
	public void add_unterKategorie(Unter_Kategorie k)
	{
		list_Kategorien.add(k);
	}
	
	public void delete_unterKategorie(Unter_Kategorie k)
	{
		list_Kategorien.remove(k);
	}
	
	public void rename_unterKategorie(String altName, String neuerName)
	{
		for(Unter_Kategorie kt: list_Kategorien)
		{
			if(kt.getName().equals(altName))
			{
				kt.setName(neuerName);
			}
		}
	}	
}
